package main

import (
	"github.com/svanhalla/base-rest-server/internal"
	"log"
)

var (
	name      = "base-rest-server"
	version   = "dev"
	buildDate = "undefined"
	user      = "unknown"
)

func main() {

	server := internal.NewServer()
	log.Fatal(server.Start(":8080"))
}
